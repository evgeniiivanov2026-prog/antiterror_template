<?php

if ( ! defined( 'WPINC' ) ) {
    die;
}

use function Wpshop\AbcPagination\get_post_anchor;
use const Wpshop\AbcPagination\META_TITLE_FOR_SORT;

/**
 * @version 1.2.0
 */

/**
 * @var array{'post':WP_Post} $args
 */

$title = $args['post']->post_title;
if ( $args['posts_short_title'] && ! empty( $meta_title = get_post_meta( $args['post']->ID, META_TITLE_FOR_SORT, true ) ) ) {
    $title = $meta_title;
}

$title = apply_filters( 'abc_pagination/post-card/title', $title );

$id = '';
if ( $args['posts_show_id'] ) {
    $id = apply_filters( 'abc_pagination/post-card/id', get_post_anchor( $title, $args['post'] ), $args['post'] );
}

?>

<div class="abc-pagination-post js-abc-pagination-post"<?php echo $id ? ' id="' . esc_attr( $id ) . '"' : '' ?>>

    <?php if ( $args['show_post_link'] ) : ?><a href="<?php the_permalink( $args['post']->ID ); ?>"><?php endif; ?>

        <?php if ( $args['show_post_thumb'] ): ?>
            <div class="abc-pagination-post__thumb">
                <?php echo get_the_post_thumbnail( $args['post']->ID, apply_filters( 'abc_pagination/post-card/thumbnail_size', 'post-thumbnail' ) ) ?>
            </div>
        <?php endif; ?>

        <div class="abc-pagination-post__title js-abc-pagination-post-title">
            <?php echo do_shortcode( esc_html( $title ) ) ?>
        </div>

        <?php if ( $args['show_post_link'] ) : ?></a><?php endif; ?>

    <?php
    if ( $args['show_post_excerpt'] ) : ?>
        <div class="abc-pagination-post__excerpt"><?php echo get_the_excerpt( $args['post'] ) ?></div>
    <?php endif ?>

    <?php if ( $args['show_post_content'] ): ?>
        <div class="abc-pagination-post__content"><?php echo get_the_content( null, false, $args['post'] ) ?></div>
    <?php endif ?>
</div>
